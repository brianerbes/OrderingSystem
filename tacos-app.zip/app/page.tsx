"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import {
  PlusCircle,
  MinusCircle,
  ShoppingCart,
  Search,
  Save,
  Trash2,
  Plus,
  User,
  LogOut,
  Settings,
  Lock,
  HelpCircle,
  X,
  Image,
  Upload,
  Store,
  RefreshCcw,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScrollArea } from "@/components/ui/scroll-area"
import { toast } from "@/components/ui/use-toast"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { cn } from "@/lib/utils"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Toaster } from "@/components/ui/toaster"
import { Slider } from "@/components/ui/slider"
import {
  Tabs as LogoTabs,
  TabsContent as LogoTabsContent,
  TabsList as LogoTabsList,
  TabsTrigger as LogoTabsTrigger,
} from "@/components/ui/tabs"

// Update the Product interface to include a more flexible category
interface Product {
  id: string
  name: string
  price: number
  quantity: number
  category: string
}

// Add a new interface for categories
interface Category {
  id: string
  name: string
  color: string
}

// Actualizar la interfaz BusinessConfig para incluir el logo y la configuración de zoom
interface BusinessConfig {
  name: string
  isConfigured: boolean
  logoUrl: string
  logoZoom: number
  logoPosition: { x: number; y: number }
}

// Update the OrderInfo interface to match the new Product interface
interface OrderInfo {
  sequentialNumber: number
  uniqueCode: string
  date: string
  products: Product[]
  total: number
  totalItems: number
}

// Helper function to get background color class based on color name
const getBgColorClass = (color: string) => {
  const colorMap: Record<string, string> = {
    red: "bg-red-500",
    green: "bg-green-500",
    blue: "bg-blue-500",
    purple: "bg-purple-500",
    pink: "bg-pink-500",
    yellow: "bg-yellow-500",
    indigo: "bg-indigo-500",
    orange: "bg-orange-500",
  }

  return colorMap[color] || "bg-gray-500"
}

// Helper function to get text color class based on color name
const getTextColorClass = (color: string) => {
  const colorMap: Record<string, string> = {
    red: "text-red-600",
    green: "text-green-600",
    blue: "text-blue-600",
    purple: "text-purple-600",
    pink: "text-pink-600",
    yellow: "text-yellow-600",
    indigo: "text-indigo-600",
    orange: "text-orange-600",
  }

  return colorMap[color] || "text-gray-600"
}

// Helper function to get hover background color class based on color name
const getHoverBgColorClass = (color: string) => {
  const colorMap: Record<string, string> = {
    red: "hover:bg-red-100",
    green: "hover:bg-green-100",
    blue: "hover:bg-blue-100",
    purple: "hover:bg-purple-100",
    pink: "hover:bg-pink-100",
    yellow: "hover:bg-yellow-100",
    indigo: "hover:bg-indigo-100",
    orange: "hover:bg-orange-100",
  }

  return colorMap[color] || "hover:bg-gray-100"
}

// Helper function to get badge background color class based on color name
const getBadgeBgColorClass = (color: string) => {
  const colorMap: Record<string, string> = {
    red: "bg-red-100",
    green: "bg-green-100",
    blue: "bg-blue-100",
    purple: "bg-purple-100",
    pink: "bg-pink-100",
    yellow: "bg-yellow-100",
    indigo: "bg-indigo-100",
    orange: "bg-orange-100",
  }

  return colorMap[color] || "bg-gray-100"
}

// Helper function to get badge text color class based on color name
const getBadgeTextColorClass = (color: string) => {
  const colorMap: Record<string, string> = {
    red: "text-red-800",
    green: "text-green-800",
    blue: "text-blue-800",
    purple: "text-purple-800",
    pink: "text-pink-800",
    yellow: "text-yellow-800",
    indigo: "text-indigo-800",
    orange: "text-orange-800",
  }

  return colorMap[color] || "text-gray-800"
}

// Helper function to get dark mode badge background color class based on color name
const getDarkBadgeBgColorClass = (color: string) => {
  const colorMap: Record<string, string> = {
    red: "dark:bg-red-900",
    green: "dark:bg-green-900",
    blue: "dark:bg-blue-900",
    purple: "dark:bg-purple-900",
    pink: "dark:bg-pink-900",
    yellow: "dark:bg-yellow-900",
    indigo: "dark:bg-indigo-900",
    orange: "dark:bg-orange-900",
  }

  return colorMap[color] || "dark:bg-gray-900"
}

// Helper function to get dark mode badge text color class based on color name
const getDarkBadgeTextColorClass = (color: string) => {
  const colorMap: Record<string, string> = {
    red: "dark:text-red-100",
    green: "dark:text-green-100",
    blue: "dark:text-blue-100",
    purple: "dark:text-purple-100",
    pink: "dark:text-pink-100",
    yellow: "dark:text-yellow-100",
    indigo: "dark:text-indigo-100",
    orange: "dark:text-orange-100",
  }

  return colorMap[color] || "dark:text-gray-100"
}

// Generate a random alphanumeric code
const generateUniqueCode = (length: number) => {
  const characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
  let result = ""
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * characters.length))
  }
  return result
}

// Replace the existing component with this updated version
export default function TacoApp() {
  // Initial categories
  const initialCategories: Category[] = []

  // Initial products
  const initialProducts: Product[] = []

  // Estados relacionados con el administrador
  const [isAdminMode, setIsAdminMode] = useState(false)
  const [isAdminDialogOpen, setIsAdminDialogOpen] = useState(false)
  const [loginPassword, setLoginPassword] = useState("")

  // Agregar estos nuevos estados después de las variables de estado existentes
  const [businessConfig, setBusinessConfig] = useState<BusinessConfig>({
    name: "Mi Negocio",
    isConfigured: false,
    logoUrl: "",
    logoZoom: 100,
    logoPosition: { x: 50, y: 50 },
  })
  const [isBusinessConfigDialogOpen, setIsBusinessConfigDialogOpen] = useState(false)
  const [newBusinessName, setNewBusinessName] = useState("")

  const [isLogoDialogOpen, setIsLogoDialogOpen] = useState(false)
  const [newLogoUrl, setNewLogoUrl] = useState("")
  const [logoZoom, setLogoZoom] = useState(100)
  const [logoPosition, setLogoPosition] = useState({ x: 50, y: 50 })
  const [logoTab, setLogoTab] = useState("url")
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [isDraggingLogo, setIsDraggingLogo] = useState(false)
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 })
  const logoContainerRef = useRef<HTMLDivElement>(null)

  // Estados para los dialogs de eliminar
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [isDeleteItemDialogOpen, setIsSetItemDeleteDialogOpen] = useState(false)

  // Estados para los dialogs de agregar
  const [isNewCategoryDialogOpen, setIsNewCategoryDialogOpen] = useState(false)
  const [isNewItemDialogOpen, setIsNewItemDialogOpen] = useState(false)

  // Estados para los inputs de agregar
  const [newCategoryName, setNewCategoryName] = useState("")
  const [newCategoryColor, setNewCategoryColor] = useState("gray")
  const [newItemName, setNewItemName] = useState("")
  const [newItemPrice, setNewItemPrice] = useState("")

  // Estado para el carrito
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false)

  // Estado para la busqueda de ordenes
  const [searchCode, setSearchCode] = useState("")
  const [foundOrder, setFoundOrder] = useState<OrderInfo | null>(null)

  // Estado para guardar el id de la categoria a eliminar
  const [categoryToDelete, setCategoryToDelete] = useState<string | null>(null)

  // Estado para guardar el id del item a eliminar
  const [itemToDelete, setItemToDelete] = useState<string | null>(null)

  // Estado para guardar la categoria actual para el nuevo item
  const [currentCategoryForNewItem, setCurrentCategoryForNewItem] = useState("")

  // Estados principales
  const [categories, setCategories] = useState<Category[]>(initialCategories)
  const [products, setProducts] = useState<Product[]>(initialProducts)
  const [orders, setOrders] = useState<OrderInfo[]>([])
  const [orderCounter, setOrderCounter] = useState(1)

  // Estado para el tutorial
  const [isTutorialOpen, setIsTutorialOpen] = useState(false)
  const [tutorialStep, setTutorialStep] = useState(1)
  const totalTutorialSteps = 5

  // Estado para el paso de configuración inicial
  const [setupStep, setSetupStep] = useState(1)

  // Estado para controlar la visibilidad del botón de usuario
  const [isUserButtonVisible, setIsUserButtonVisible] = useState(false)

  // Load data from localStorage on component mount
  useEffect(() => {
    const savedCategories = localStorage.getItem("categories")
    const savedProducts = localStorage.getItem("products")
    const savedOrders = localStorage.getItem("orders")
    const savedCounter = localStorage.getItem("orderCounter")
    const savedBusinessConfig = localStorage.getItem("businessConfig")

    if (savedCategories) {
      setCategories(JSON.parse(savedCategories))
    }

    if (savedProducts) {
      setProducts(JSON.parse(savedProducts))
    }

    if (savedOrders) {
      setOrders(JSON.parse(savedOrders))
    }

    if (savedCounter) {
      setOrderCounter(Number.parseInt(savedCounter))
    }

    if (savedBusinessConfig) {
      const config = JSON.parse(savedBusinessConfig)
      setBusinessConfig(config)
      // Asegurarse de que los nuevos campos existan
      if (config.logoZoom === undefined) {
        setBusinessConfig({
          ...config,
          logoZoom: 100,
          logoPosition: { x: 50, y: 50 },
        })
      }
    } else {
      // Si no hay configuración de negocio guardada, abrir el diálogo de configuración
      setIsBusinessConfigDialogOpen(true)
      setNewBusinessName("Mi Negocio")
    }
  }, [])

  // Mostrar tutorial después de configurar el negocio si es la primera vez
  useEffect(() => {
    if (businessConfig.isConfigured && !localStorage.getItem("tutorialShown")) {
      setIsTutorialOpen(true)
      localStorage.setItem("tutorialShown", "true")
    }
  }, [businessConfig.isConfigured])

  // Agregar efecto para guardar la configuración del negocio
  useEffect(() => {
    localStorage.setItem("businessConfig", JSON.stringify(businessConfig))
  }, [businessConfig])

  // Save data to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem("categories", JSON.stringify(categories))
    localStorage.setItem("products", JSON.stringify(products))
    localStorage.setItem("orders", JSON.stringify(orders))
    localStorage.setItem("orderCounter", orderCounter.toString())
  }, [categories, products, orders, orderCounter])

  // Efecto para detectar la posición del ratón
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const windowWidth = window.innerWidth
      const threshold = windowWidth * 0.1 // 10% del ancho de la ventana desde el borde derecho

      if (windowWidth - e.clientX < threshold) {
        setIsUserButtonVisible(true)
      } else {
        setIsUserButtonVisible(false)
      }
    }

    window.addEventListener("mousemove", handleMouseMove)

    return () => {
      window.removeEventListener("mousemove", handleMouseMove)
    }
  }, [])

  // Calculate order totals
  const calculateOrderTotals = () => {
    const selectedProducts = products.filter((product) => product.quantity > 0)
    const totalItems = selectedProducts.reduce((sum, product) => sum + product.quantity, 0)
    const totalPrice = selectedProducts.reduce((sum, product) => sum + product.price * product.quantity, 0)

    return { selectedProducts, totalItems, totalPrice }
  }

  // Get current date and time
  const getCurrentDateTime = () => {
    const now = new Date()
    return now.toLocaleString()
  }

  // Handle quantity changes
  const updateQuantity = (id: string, delta: number) => {
    setProducts(
      products.map((product) =>
        product.id === id ? { ...product, quantity: Math.max(0, product.quantity + delta) } : product,
      ),
    )
  }

  // Handle direct quantity input
  const setQuantity = (id: string, quantity: number) => {
    const validQuantity = Math.max(0, quantity)
    setProducts(products.map((product) => (product.id === id ? { ...product, quantity: validQuantity } : product)))
  }

  // Función para simular la carga de un archivo
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      // En un entorno real, aquí subiríamos el archivo a un servidor
      // Para esta demo, simularemos que tenemos una URL
      const fakeUrl = URL.createObjectURL(file)
      setNewLogoUrl(fakeUrl)
      toast({
        title: "Imagen cargada",
        description: "La imagen se ha cargado correctamente",
      })
    }
  }

  // Función para manejar el inicio del arrastre del logo
  const handleLogoMouseDown = (e: React.MouseEvent) => {
    setIsDraggingLogo(true)
    setDragStart({ x: e.clientX, y: e.clientY })
  }

  // Función para manejar el movimiento del logo
  const handleLogoMouseMove = (e: React.MouseEvent) => {
    if (isDraggingLogo && logoContainerRef.current) {
      const deltaX = e.clientX - dragStart.x
      const deltaY = e.clientY - dragStart.y

      const containerRect = logoContainerRef.current.getBoundingClientRect()
      const containerWidth = containerRect.width
      const containerHeight = containerRect.height

      // Calcular el nuevo porcentaje de posición
      const newX = Math.max(0, Math.min(100, logoPosition.x + (deltaX / containerWidth) * 100))
      const newY = Math.max(0, Math.min(100, logoPosition.y + (deltaY / containerHeight) * 100))

      setLogoPosition({ x: newX, y: newY })
      setDragStart({ x: e.clientX, y: e.clientY })
    }
  }

  // Función para manejar el fin del arrastre del logo
  const handleLogoMouseUp = () => {
    setIsDraggingLogo(false)
  }

  // Función para usar el logo predeterminado
  const useDefaultLogo = () => {
    setNewLogoUrl("default")
    setLogoZoom(100)
    setLogoPosition({ x: 50, y: 50 })
  }

  // Función para guardar el logo
  const saveLogo = () => {
    setBusinessConfig({
      ...businessConfig,
      logoUrl: newLogoUrl,
      logoZoom: logoZoom,
      logoPosition: logoPosition,
    })
    setIsLogoDialogOpen(false)

    toast({
      title: "Logo actualizado",
      description: "El logo del negocio ha sido actualizado",
    })
  }

  // Función para continuar con la configuración inicial
  const continueSetup = () => {
    if (setupStep === 1) {
      if (!newBusinessName.trim()) {
        toast({
          title: "Error",
          description: "Por favor ingrese un nombre para su negocio",
          variant: "destructive",
        })
        return
      }
      setSetupStep(2)
    } else {
      // Guardar toda la configuración
      // Si no se ha seleccionado un logo, usar el predeterminado
      const finalLogoUrl = newLogoUrl || "default"

      setBusinessConfig({
        name: newBusinessName,
        isConfigured: true,
        logoUrl: finalLogoUrl,
        logoZoom: logoZoom,
        logoPosition: logoPosition,
      })
      setIsBusinessConfigDialogOpen(false)
      setNewBusinessName("")
      setSetupStep(1)

      toast({
        title: "Configuración guardada",
        description: "La configuración del negocio ha sido guardada",
      })
    }
  }

  // Agregar función para guardar la configuración del negocio
  const saveBusinessConfig = () => {
    if (!newBusinessName.trim()) {
      toast({
        title: "Error",
        description: "Por favor ingrese un nombre para su negocio",
        variant: "destructive",
      })
      return
    }

    setBusinessConfig({
      ...businessConfig,
      name: newBusinessName,
      isConfigured: true,
    })
    setIsBusinessConfigDialogOpen(false)
    setNewBusinessName("")

    toast({
      title: "Configuración guardada",
      description: "El nombre del negocio ha sido actualizado",
    })
  }

  // Modificar la función loginAsAdmin para usar la contraseña hardcodeada
  const loginAsAdmin = () => {
    if (loginPassword === "admin") {
      setIsAdminMode(true)
      setIsAdminDialogOpen(false)
      setLoginPassword("")

      toast({
        title: "Modo administrador activado",
        description: "Ahora puede editar el menú y ver las órdenes",
      })
    } else {
      toast({
        title: "Error de autenticación",
        description: "Contraseña incorrecta",
        variant: "destructive",
      })
    }
  }

  // Logout from admin mode
  const logoutFromAdmin = () => {
    setIsAdminMode(false)

    toast({
      title: "Sesión cerrada",
      description: "Ha salido del modo administrador",
    })
  }

  // Add a new custom item
  const addNewItem = () => {
    if (!newItemName.trim() || !newItemPrice.trim()) {
      toast({
        title: "Error",
        description: "Por favor ingrese nombre y precio para el nuevo producto",
        variant: "destructive",
      })
      return
    }

    const price = Number.parseFloat(newItemPrice)
    if (isNaN(price) || price <= 0) {
      toast({
        title: "Error",
        description: "Por favor ingrese un precio válido",
        variant: "destructive",
      })
      return
    }

    // Verificar si hay categorías disponibles
    if (categories.length === 0) {
      toast({
        title: "Error",
        description: "No hay categorías disponibles. Por favor, cree una categoría primero.",
        variant: "destructive",
      })
      return
    }

    // Usar la categoría seleccionada para el nuevo item
    const categoryId = currentCategoryForNewItem

    const newItem: Product = {
      id: `${categoryId[0]}${Date.now()}`,
      name: newItemName,
      price: price,
      quantity: 0,
      category: categoryId,
    }

    setProducts([...products, newItem])
    setNewItemName("")
    setNewItemPrice("")
    setIsNewItemDialogOpen(false)

    toast({
      title: "Producto agregado",
      description: `${newItemName} ha sido agregado a la lista de productos`,
    })
  }

  // Add a new category
  const addNewCategory = () => {
    if (!newCategoryName.trim()) {
      toast({
        title: "Error",
        description: "Por favor ingrese un nombre para la categoría",
        variant: "destructive",
      })
      return
    }

    const categoryId = newCategoryName.toLowerCase().replace(/\s+/g, "-")

    // Check if category already exists
    if (categories.some((cat) => cat.id === categoryId)) {
      toast({
        title: "Error",
        description: "Ya existe una categoría con ese nombre",
        variant: "destructive",
      })
      return
    }

    const newCategory: Category = {
      id: categoryId,
      name: newCategoryName,
      color: newCategoryColor,
    }

    setCategories([...categories, newCategory])
    setNewCategoryName("")
    setIsNewCategoryDialogOpen(false)

    toast({
      title: "Categoría agregada",
      description: `La categoría ${newCategoryName} ha sido agregada`,
    })
  }

  // Remove an item from the menu
  const removeItem = (id: string) => {
    setProducts(products.filter((product) => product.id !== id))

    toast({
      title: "Producto eliminado",
      description: "El producto ha sido eliminado del menú",
    })
  }

  // Remove a category and handle its products
  const removeCategory = (categoryId: string) => {
    console.log("Intentando eliminar categoría:", categoryId)

    // Ask what to do with products in this category
    const productsInCategory = products.filter((p) => p.category === categoryId)

    if (productsInCategory.length > 0) {
      // Remove the products in this category
      setProducts(products.filter((p) => p.category !== categoryId))

      const categoryName = getCategoryName(categoryId)
      toast({
        title: `${productsInCategory.length} productos eliminados`,
        description: `Se eliminaron los productos de la categoría ${categoryName}`,
      })
    }

    // Remove the category
    setCategories(categories.filter((c) => c.id !== categoryId))

    toast({
      title: "Categoría eliminada",
      description: `La categoría ha sido eliminada del menú`,
    })
  }

  // Save the current order
  const saveOrder = () => {
    const { selectedProducts, totalItems, totalPrice } = calculateOrderTotals()

    if (totalItems === 0) {
      toast({
        title: "Error",
        description: "No hay productos seleccionados para guardar",
        variant: "destructive",
      })
      return
    }

    const newOrder: OrderInfo = {
      sequentialNumber: orderCounter,
      uniqueCode: generateUniqueCode(5),
      date: getCurrentDateTime(),
      products: selectedProducts,
      total: totalPrice,
      totalItems: totalItems,
    }

    setOrders([...orders, newOrder])
    setOrderCounter((prev) => (prev + 1) % 1000)

    // Reset quantities
    setProducts(products.map((product) => ({ ...product, quantity: 0 })))

    setIsCheckoutOpen(false)

    toast({
      title: "Orden guardada",
      description: `Orden #${newOrder.sequentialNumber.toString().padStart(3, "0")} (ID: ${newOrder.uniqueCode}) guardada exitosamente`,
    })
  }

  // Search for an order by its unique code
  const searchOrder = () => {
    if (!searchCode.trim()) {
      toast({
        title: "Error",
        description: "Por favor ingrese un código de orden",
        variant: "destructive",
      })
      return
    }

    const order = orders.find((order) => order.uniqueCode === searchCode)
    if (order) {
      setFoundOrder(order)
    } else {
      toast({
        title: "No encontrado",
        description: `No se encontró ninguna orden con el código ${searchCode}`,
        variant: "destructive",
      })
    }
  }

  // Get category color
  const getCategoryColor = (categoryId: string) => {
    const category = categories.find((cat) => cat.id === categoryId)
    return category ? category.color : "gray"
  }

  // Get category name
  const getCategoryName = (categoryId: string) => {
    const category = categories.find((cat) => cat.id === categoryId)
    return category ? category.name : categoryId
  }

  // Open new item dialog with the correct category
  const openNewItemDialog = (categoryId: string) => {
    setCurrentCategoryForNewItem(categoryId)
    setIsNewItemDialogOpen(true)
  }

  // Avanzar al siguiente paso del tutorial
  const nextTutorialStep = () => {
    if (tutorialStep < totalTutorialSteps) {
      setTutorialStep(tutorialStep + 1)
    } else {
      setIsTutorialOpen(false)
      setTutorialStep(1)
    }
  }

  // Retroceder al paso anterior del tutorial
  const prevTutorialStep = () => {
    if (tutorialStep > 1) {
      setTutorialStep(tutorialStep - 1)
    }
  }

  // Cerrar el tutorial
  const closeTutorial = () => {
    setIsTutorialOpen(false)
    setTutorialStep(1)
  }

  // Renderizar el contenido del tutorial según el paso actual
  const renderTutorialContent = () => {
    switch (tutorialStep) {
      case 1:
        return (
          <>
            <h3 className="text-lg font-semibold mb-2">Bienvenido a tu Sistema de Pedidos</h3>
            <p className="mb-4">
              Este sistema te permite gestionar tu menú y tomar pedidos de manera sencilla. Vamos a ver cómo funciona.
            </p>
            <div className="flex justify-center mb-4">
              <div className="bg-orange-100 p-4 rounded-lg">
                <ShoppingCart className="h-12 w-12 text-orange-500 mx-auto mb-2" />
                <p className="text-center text-sm">Sistema de Pedidos</p>
              </div>
            </div>
          </>
        )
      case 2:
        return (
          <>
            <h3 className="text-lg font-semibold mb-2">Modo Administrador</h3>
            <p className="mb-4">
              Para editar tu menú, necesitas entrar en modo administrador. Haz clic en el icono de usuario en la esquina
              superior derecha y selecciona "Modo Administrador".
            </p>
            <div className="flex justify-center mb-4">
              <div className="bg-gray-100 p-4 rounded-lg">
                <User className="h-8 w-8 text-gray-500 mx-auto mb-2" />
                <p className="text-center text-sm">Contraseña: "admin"</p>
              </div>
            </div>
          </>
        )
      case 3:
        return (
          <>
            <h3 className="text-lg font-semibold mb-2">Gestión del Menú</h3>
            <p className="mb-4">
              En modo administrador, puedes crear categorías y agregar productos a cada categoría. Cada producto tendrá
              un nombre y un precio.
            </p>
            <div className="flex justify-center gap-4 mb-4">
              <div className="bg-green-100 p-3 rounded-lg">
                <Plus className="h-6 w-6 text-green-500 mx-auto mb-1" />
                <p className="text-center text-xs">Nueva Categoría</p>
              </div>
              <div className="bg-blue-100 p-3 rounded-lg">
                <PlusCircle className="h-6 w-6 text-blue-500 mx-auto mb-1" />
                <p className="text-center text-xs">Nuevo Producto</p>
              </div>
            </div>
          </>
        )
      case 4:
        return (
          <>
            <h3 className="text-lg font-semibold mb-2">Tomar Pedidos</h3>
            <p className="mb-4">
              Para tomar un pedido, simplemente selecciona los productos y ajusta las cantidades usando los botones + y
              -. El total se calculará automáticamente.
            </p>
            <div className="flex justify-center gap-4 mb-4">
              <div className="bg-gray-100 p-3 rounded-lg">
                <MinusCircle className="h-6 w-6 text-gray-500 mx-auto mb-1" />
                <p className="text-center text-xs">Disminuir</p>
              </div>
              <div className="bg-gray-100 p-3 rounded-lg">
                <span className="block text-center font-bold text-lg mb-1">2</span>
                <p className="text-center text-xs">Cantidad</p>
              </div>
              <div className="bg-gray-100 p-3 rounded-lg">
                <PlusCircle className="h-6 w-6 text-gray-500 mx-auto mb-1" />
                <p className="text-center text-xs">Aumentar</p>
              </div>
            </div>
          </>
        )
      case 5:
        return (
          <>
            <h3 className="text-lg font-semibold mb-2">Historial de Órdenes</h3>
            <p className="mb-4">
              En modo administrador, puedes ver el historial de órdenes y buscar órdenes específicas por su código
              único.
            </p>
            <div className="flex justify-center mb-4">
              <div className="bg-purple-100 p-4 rounded-lg">
                <Search className="h-8 w-8 text-purple-500 mx-auto mb-2" />
                <p className="text-center text-sm">Buscar Órdenes</p>
              </div>
            </div>
            <p className="text-center text-sm text-muted-foreground">
              Puedes volver a ver este tutorial en cualquier momento desde el menú de usuario.
            </p>
          </>
        )
      default:
        return null
    }
  }

  // Renderizar el logo
  const renderLogo = () => {
    if (businessConfig.logoUrl === "default") {
      return (
        <div className="h-10 w-10 rounded-full overflow-hidden border-2 border-orange-300 flex items-center justify-center bg-orange-200">
          <Store className="h-6 w-6 text-orange-600" />
        </div>
      )
    } else if (businessConfig.logoUrl) {
      return (
        <div className="h-10 w-10 rounded-full overflow-hidden border-2 border-orange-300">
          <div
            className="h-full w-full"
            style={{
              backgroundImage: `url(${businessConfig.logoUrl})`,
              backgroundSize: `${businessConfig.logoZoom}%`,
              backgroundPosition: `${businessConfig.logoPosition.x}% ${businessConfig.logoPosition.y}%`,
              backgroundRepeat: "no-repeat",
            }}
          />
        </div>
      )
    }
    return null
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-orange-100 dark:from-stone-900 dark:to-stone-800">
      <header className="bg-orange-600 text-white p-4 shadow-md dark:bg-stone-800">
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex items-center gap-3">
            {renderLogo()}
            <h1 className="text-3xl font-bold">{businessConfig.name.toUpperCase()}</h1>
          </div>
          <div className="flex items-center gap-2">
            <div
              className={`transition-opacity duration-300 ${isUserButtonVisible ? "opacity-100" : "opacity-0 pointer-events-none"}`}
            >
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="h-8 w-8 rounded-full">
                    <User className="h-5 w-5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>Mi Cuenta</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  {isAdminMode ? (
                    <>
                      <DropdownMenuItem
                        onClick={() => {
                          setNewBusinessName(businessConfig.name)
                          setIsBusinessConfigDialogOpen(true)
                        }}
                      >
                        <Settings className="mr-2 h-4 w-4" />
                        <span>Cambiar Nombre del Negocio</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        onClick={() => {
                          setNewLogoUrl(businessConfig.logoUrl)
                          setLogoZoom(businessConfig.logoZoom)
                          setLogoPosition(businessConfig.logoPosition)
                          setIsLogoDialogOpen(true)
                        }}
                      >
                        <Image className="mr-2 h-4 w-4" />
                        <span>Cambiar Logo</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setIsTutorialOpen(true)}>
                        <HelpCircle className="mr-2 h-4 w-4" />
                        <span>Ver Tutorial</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={logoutFromAdmin}>
                        <LogOut className="mr-2 h-4 w-4" />
                        <span>Salir de Modo Admin</span>
                      </DropdownMenuItem>
                    </>
                  ) : (
                    <>
                      <DropdownMenuItem onClick={() => setIsAdminDialogOpen(true)}>
                        <Settings className="mr-2 h-4 w-4" />
                        <span>Modo Administrador</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setIsTutorialOpen(true)}>
                        <HelpCircle className="mr-2 h-4 w-4" />
                        <span>Ver Tutorial</span>
                      </DropdownMenuItem>
                    </>
                  )}
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
        <p className="text-center text-orange-100 flex items-center justify-center gap-2">
          <ShoppingCart className="h-4 w-4" />
          Sistema de Pedidos v1.0 {isAdminMode && "- Modo Administrador"}
        </p>
      </header>

      <main className="container mx-auto p-4 md:p-6 pb-32">
        <Tabs defaultValue="menu" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="menu">Menú</TabsTrigger>
            {isAdminMode && <TabsTrigger value="orders">Órdenes</TabsTrigger>}
          </TabsList>

          {/* MENU TAB */}
          <TabsContent value="menu" className="space-y-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-2xl font-bold">Menú</h2>
              {isAdminMode && (
                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => setIsNewCategoryDialogOpen(true)}>
                    <Plus className="h-4 w-4 mr-2" /> Nueva Categoría
                  </Button>
                </div>
              )}
            </div>

            {categories.length === 0 ? (
              <div className="text-center py-12 bg-white rounded-lg shadow dark:bg-stone-800">
                <h3 className="text-xl font-medium mb-2">No hay categorías</h3>
                <p className="text-muted-foreground mb-4">
                  {isAdminMode
                    ? "Agregue una categoría para comenzar a crear su menú"
                    : "No hay productos disponibles en este momento"}
                </p>
                {isAdminMode && (
                  <Button onClick={() => setIsNewCategoryDialogOpen(true)}>
                    <Plus className="h-4 w-4 mr-2" /> Agregar Categoría
                  </Button>
                )}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* CATEGORIES SECTION */}
                {categories.map((category) => (
                  <Card key={category.id}>
                    <CardHeader
                      className={cn("text-white rounded-t-lg dark:bg-stone-700", getBgColorClass(category.color))}
                    >
                      <CardTitle className="flex justify-between items-center">
                        <span>{category.name}</span>
                        {isAdminMode && (
                          <div className="flex gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              className="bg-white text-red-600 hover:bg-red-100 dark:bg-stone-800 dark:text-white dark:hover:bg-red-900"
                              onClick={() => {
                                setCategoryToDelete(category.id)
                                setIsDeleteDialogOpen(true)
                              }}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              className={cn(
                                "bg-white dark:bg-stone-800 dark:text-white dark:hover:bg-stone-700",
                                getTextColorClass(category.color),
                                getHoverBgColorClass(category.color),
                              )}
                              onClick={() => openNewItemDialog(category.id)}
                            >
                              <PlusCircle className="h-4 w-4 mr-1" /> Agregar
                            </Button>
                          </div>
                        )}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="pt-4">
                      <ScrollArea className="h-[400px] pr-4">
                        <div className="space-y-4">
                          {products
                            .filter((product) => product.category === category.id)
                            .map((product) => (
                              <div
                                key={product.id}
                                className="flex items-center justify-between p-3 border rounded-lg bg-white dark:bg-stone-800 dark:border-stone-700"
                              >
                                <div>
                                  <h3 className="font-medium">{product.name}</h3>
                                  <p className="text-sm text-muted-foreground">${product.price.toFixed(2)}</p>
                                </div>
                                <div className="flex items-center space-x-2">
                                  <Button
                                    variant="outline"
                                    size="icon"
                                    onClick={() => updateQuantity(product.id, -1)}
                                    disabled={product.quantity === 0}
                                  >
                                    <MinusCircle className="h-4 w-4" />
                                  </Button>
                                  <span className="w-8 text-center font-medium text-lg">{product.quantity}</span>
                                  <Button variant="outline" size="icon" onClick={() => updateQuantity(product.id, 1)}>
                                    <PlusCircle className="h-4 w-4" />
                                  </Button>
                                  {isAdminMode && (
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      className="text-red-500 hover:text-red-700 hover:bg-red-100 dark:hover:bg-red-900"
                                      onClick={() => {
                                        setItemToDelete(product.id)
                                        setIsSetItemDeleteDialogOpen(true)
                                      }}
                                    >
                                      <Trash2 className="h-4 w-4" />
                                    </Button>
                                  )}
                                </div>
                              </div>
                            ))}
                          {products.filter((product) => product.category === category.id).length === 0 && (
                            <div className="text-center py-8 text-muted-foreground">
                              No hay productos en esta categoría
                            </div>
                          )}
                        </div>
                      </ScrollArea>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* ORDERS TAB - Only visible in admin mode */}
          {isAdminMode && (
            <TabsContent value="orders">
              <Card>
                <CardHeader className="bg-purple-600 text-white rounded-t-lg dark:bg-stone-700">
                  <CardTitle>Historial de Órdenes</CardTitle>
                </CardHeader>
                <CardContent className="pt-6">
                  <div className="flex gap-2 mb-6">
                    <Input
                      placeholder="Ingrese código de orden"
                      value={searchCode}
                      onChange={(e) => setSearchCode(e.target.value)}
                    />
                    <Button onClick={searchOrder}>
                      <Search className="h-4 w-4 mr-2" /> Buscar
                    </Button>
                  </div>

                  {foundOrder ? (
                    <Card className="border-2 border-purple-200 dark:border-purple-900">
                      <CardHeader className="bg-purple-100 dark:bg-purple-900">
                        <CardTitle className="text-lg">
                          Orden #{foundOrder.sequentialNumber.toString().padStart(3, "0")}
                          <span className="ml-2 text-sm font-normal">(ID: {foundOrder.uniqueCode})</span>
                        </CardTitle>
                        <p className="text-sm text-muted-foreground">{foundOrder.date}</p>
                      </CardHeader>
                      <CardContent className="pt-4">
                        <div className="space-y-4">
                          {/* Group products by category */}
                          {categories.map((category) => {
                            const categoryProducts = foundOrder.products.filter((p) => p.category === category.id)
                            if (categoryProducts.length === 0) return null

                            return (
                              <div key={category.id}>
                                <h3 className="font-medium mb-2">{category.name}</h3>
                                <div className="space-y-2">
                                  {categoryProducts.map((product, idx) => (
                                    <div key={idx} className="flex justify-between text-sm">
                                      <span>
                                        {product.quantity}x {product.name}
                                      </span>
                                      <span>${(product.price * product.quantity).toFixed(2)}</span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )
                          })}

                          <div className="pt-4 border-t dark:border-stone-700">
                            <div className="flex justify-between">
                              <span>Total Items:</span>
                              <span>{foundOrder.totalItems}</span>
                            </div>
                            <div className="flex justify-between font-bold">
                              <span>Total:</span>
                              <span>${foundOrder.total.toFixed(2)}</span>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ) : (
                    <div className="text-center py-12">
                      <Search className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                      <h3 className="text-xl font-medium mb-2">Buscar Órdenes</h3>
                      <p className="text-muted-foreground">Ingrese el código de la orden para ver los detalles</p>
                    </div>
                  )}

                  {orders.length > 0 && (
                    <div className="mt-8">
                      <h3 className="font-medium mb-4">Órdenes Recientes</h3>
                      <div className="space-y-2">
                        {orders
                          .slice()
                          .reverse()
                          .map((order) => (
                            <div
                              key={order.uniqueCode}
                              className="p-3 border rounded-lg cursor-pointer hover:bg-gray-50 dark:hover:bg-stone-800 dark:border-stone-700"
                              onClick={() => {
                                setSearchCode(order.uniqueCode)
                                setFoundOrder(order)
                              }}
                            >
                              <div className="flex justify-between">
                                <div>
                                  <div className="font-medium">
                                    Orden #{order.sequentialNumber.toString().padStart(3, "0")}
                                  </div>
                                  <div className="text-sm text-muted-foreground">ID: {order.uniqueCode}</div>
                                </div>
                                <div className="text-right">
                                  <div>${order.total.toFixed(2)}</div>
                                  <div className="text-sm text-muted-foreground">{order.totalItems} items</div>
                                </div>
                              </div>
                            </div>
                          ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          )}
        </Tabs>
      </main>

      {/* Fixed Cart Summary at Bottom */}
      <div className="fixed bottom-0 left-0 right-0 bg-white dark:bg-stone-800 border-t border-gray-200 dark:border-stone-700 shadow-lg p-4 z-50">
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex items-center gap-4">
            <ShoppingCart className="h-6 w-6 text-orange-500" />
            <div>
              <div className="text-sm text-muted-foreground">Total:</div>
              <div className="font-bold">${calculateOrderTotals().totalPrice.toFixed(2)}</div>
            </div>
            <div className="text-sm text-muted-foreground">{calculateOrderTotals().totalItems} items</div>
          </div>
          <Button size="lg" disabled={calculateOrderTotals().totalItems === 0} onClick={() => setIsCheckoutOpen(true)}>
            Confirmar Pedido
          </Button>
        </div>
      </div>

      {/* MODALS */}
      {/* Checkout Dialog */}
      <Dialog open={isCheckoutOpen} onOpenChange={setIsCheckoutOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Confirmar Pedido</DialogTitle>
            <DialogDescription>Revise su pedido antes de confirmar</DialogDescription>
          </DialogHeader>

          <div className="space-y-4 my-4">
            <div className="border rounded-lg p-4 dark:border-stone-700">
              <h3 className="font-medium mb-2">Resumen del Pedido</h3>

              {/* Products by category */}
              {categories.map((category) => {
                const categoryProducts = products.filter((p) => p.category === category.id && p.quantity > 0)
                if (categoryProducts.length === 0) return null

                return (
                  <div key={category.id} className="mb-3">
                    <h4 className="text-sm font-medium text-muted-foreground mb-1">{category.name}:</h4>
                    {categoryProducts.map((product) => (
                      <div key={product.id} className="flex justify-between text-sm">
                        <span>
                          {product.quantity}x {product.name}
                        </span>
                        <span>${(product.price * product.quantity).toFixed(2)}</span>
                      </div>
                    ))}
                  </div>
                )
              })}

              <div className="border-t pt-2 mt-2 dark:border-stone-700">
                <div className="flex justify-between font-medium">
                  <span>Total Items:</span>
                  <span>{calculateOrderTotals().totalItems}</span>
                </div>
                <div className="flex justify-between font-bold">
                  <span>Total:</span>
                  <span>${calculateOrderTotals().totalPrice.toFixed(2)}</span>
                </div>
              </div>
            </div>

            <div className="text-sm text-muted-foreground">
              Al confirmar, se generará un código único para su pedido que podrá usar para consultarlo posteriormente.
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCheckoutOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={saveOrder}>
              <Save className="h-4 w-4 mr-2" /> Confirmar Pedido
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Category Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>¿Eliminar categoría?</DialogTitle>
            <DialogDescription>
              Esta acción eliminará la categoría y todos los productos asociados a ella. Esta acción no se puede
              deshacer.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Cancelar
            </Button>
            <Button
              variant="destructive"
              onClick={() => {
                if (categoryToDelete) {
                  removeCategory(categoryToDelete)
                  setCategoryToDelete(null)
                }
                setIsDeleteDialogOpen(false)
              }}
            >
              Eliminar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Item Dialog */}
      <Dialog open={isDeleteItemDialogOpen} onOpenChange={setIsSetItemDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>¿Eliminar producto?</DialogTitle>
            <DialogDescription>
              Esta acción eliminará el producto seleccionado. Esta acción no se puede deshacer.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsSetItemDeleteDialogOpen(false)}>
              Cancelar
            </Button>
            <Button
              variant="destructive"
              onClick={() => {
                if (itemToDelete) {
                  removeItem(itemToDelete)
                  setItemToDelete(null)
                }
                setIsSetItemDeleteDialogOpen(false)
              }}
            >
              Eliminar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* New Category Dialog */}
      <Dialog open={isNewCategoryDialogOpen} onOpenChange={setIsNewCategoryDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Agregar Nueva Categoría</DialogTitle>
            <DialogDescription>Cree una nueva categoría para organizar sus productos.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="category-name" className="text-right">
                Nombre
              </Label>
              <Input
                id="category-name"
                value={newCategoryName}
                onChange={(e) => setNewCategoryName(e.target.value)}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="category-color" className="text-right">
                Color
              </Label>
              <Select value={newCategoryColor} onValueChange={setNewCategoryColor}>
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Seleccione un color" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="red">Rojo</SelectItem>
                  <SelectItem value="green">Verde</SelectItem>
                  <SelectItem value="blue">Azul</SelectItem>
                  <SelectItem value="purple">Morado</SelectItem>
                  <SelectItem value="pink">Rosa</SelectItem>
                  <SelectItem value="yellow">Amarillo</SelectItem>
                  <SelectItem value="indigo">Índigo</SelectItem>
                  <SelectItem value="orange">Naranja</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={addNewCategory}>Agregar Categoría</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* New Item Dialog */}
      <Dialog open={isNewItemDialogOpen} onOpenChange={setIsNewItemDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Agregar Nuevo Producto</DialogTitle>
            <DialogDescription>Ingrese los detalles del nuevo producto para agregarlo al menú.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="name" className="text-right">
                Nombre
              </Label>
              <Input
                id="name"
                value={newItemName}
                onChange={(e) => setNewItemName(e.target.value)}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="price" className="text-right">
                Precio
              </Label>
              <Input
                id="price"
                type="number"
                min="0"
                step="0.01"
                value={newItemPrice}
                onChange={(e) => setNewItemPrice(e.target.value)}
                className="col-span-3"
              />
            </div>
          </div>
          <DialogFooter>
            <Button onClick={addNewItem}>Agregar Producto</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Admin Login Dialog */}
      <Dialog open={isAdminDialogOpen} onOpenChange={setIsAdminDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Acceso Administrador</DialogTitle>
            <DialogDescription>Ingrese la contraseña para acceder al modo de edición.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="password" className="text-right">
                Contraseña
              </Label>
              <Input
                id="password"
                type="password"
                value={loginPassword}
                onChange={(e) => setLoginPassword(e.target.value)}
                className="col-span-3"
              />
            </div>
          </div>
          <DialogFooter>
            <Button onClick={loginAsAdmin}>
              <Lock className="h-4 w-4 mr-2" /> Iniciar Sesión
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Business Config Dialog */}
      <Dialog
        open={isBusinessConfigDialogOpen}
        onOpenChange={(open) => {
          // Solo permitir cerrar el diálogo si ya está configurado
          if (!open && !businessConfig.isConfigured) {
            return
          }
          setIsBusinessConfigDialogOpen(open)
        }}
      >
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Configuración del Negocio</DialogTitle>
            <DialogDescription>
              {setupStep === 1
                ? "Ingrese el nombre de su negocio para personalizarlo."
                : "Configure el logo de su negocio (opcional)."}
            </DialogDescription>
          </DialogHeader>

          {setupStep === 1 ? (
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="business-name" className="text-right">
                  Nombre
                </Label>
                <Input
                  id="business-name"
                  value={newBusinessName}
                  onChange={(e) => setNewBusinessName(e.target.value)}
                  placeholder="Mi Negocio"
                  className="col-span-3"
                />
              </div>
            </div>
          ) : (
            <div className="space-y-4 py-4">
              <LogoTabs value={logoTab} onValueChange={setLogoTab} className="w-full">
                <LogoTabsList className="grid w-full grid-cols-2">
                  <LogoTabsTrigger value="url">URL</LogoTabsTrigger>
                  <LogoTabsTrigger value="upload">Subir</LogoTabsTrigger>
                </LogoTabsList>

                <LogoTabsContent value="url" className="pt-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="logo-url" className="text-right">
                      URL
                    </Label>
                    <Input
                      id="logo-url"
                      value={newLogoUrl}
                      onChange={(e) => setNewLogoUrl(e.target.value)}
                      placeholder="https://ejemplo.com/mi-logo.png"
                      className="col-span-3"
                    />
                  </div>
                </LogoTabsContent>

                <LogoTabsContent value="upload" className="pt-4">
                  <div className="flex flex-col items-center gap-4">
                    <div
                      className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center cursor-pointer hover:bg-gray-50 dark:hover:bg-stone-800"
                      onClick={() => fileInputRef.current?.click()}
                    >
                      <Upload className="h-8 w-8 mx-auto mb-2 text-gray-400" />
                      <p className="text-sm text-muted-foreground">Haga clic para seleccionar una imagen</p>
                      <input
                        type="file"
                        ref={fileInputRef}
                        className="hidden"
                        accept="image/*"
                        onChange={handleFileUpload}
                      />
                    </div>
                  </div>
                </LogoTabsContent>
              </LogoTabs>

              <div className="flex justify-center mt-4">
                <Button
                  variant="outline"
                  onClick={() => {
                    setNewLogoUrl("default")
                    toast({
                      title: "Logo predeterminado seleccionado",
                      description: "Se usará el logo predeterminado",
                    })
                  }}
                  className="flex items-center gap-2"
                >
                  <Store className="h-4 w-4" />
                  <span>Usar Logo Predeterminado</span>
                </Button>
              </div>

              {newLogoUrl && newLogoUrl !== "default" && (
                <div className="space-y-4 pt-4">
                  <div className="border-t pt-4 dark:border-stone-700">
                    <h3 className="text-sm font-medium mb-2">Ajustar Logo</h3>

                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="logo-zoom">Zoom</Label>
                        <Slider
                          id="logo-zoom"
                          min={50}
                          max={200}
                          step={5}
                          value={[logoZoom]}
                          onValueChange={(value) => setLogoZoom(value[0])}
                        />
                        <div className="flex justify-between text-xs text-muted-foreground">
                          <span>50%</span>
                          <span>100%</span>
                          <span>200%</span>
                        </div>
                      </div>

                      <div className="mt-4">
                        <Label className="mb-2 block">Posición (Arrastre la imagen para ajustar)</Label>
                        <div
                          ref={logoContainerRef}
                          className="h-40 w-40 mx-auto border-2 border-orange-300 rounded-lg overflow-hidden relative"
                          onMouseMove={handleLogoMouseMove}
                          onMouseUp={handleLogoMouseUp}
                          onMouseLeave={handleLogoMouseUp}
                        >
                          <div
                            className="absolute inset-0 cursor-move"
                            style={{
                              backgroundImage: `url(${newLogoUrl})`,
                              backgroundSize: `${logoZoom}%`,
                              backgroundPosition: `${logoPosition.x}% ${logoPosition.y}%`,
                              backgroundRepeat: "no-repeat",
                            }}
                            onMouseDown={handleLogoMouseDown}
                          />
                        </div>
                      </div>

                      <div className="flex justify-center mt-4">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setLogoZoom(100)
                            setLogoPosition({ x: 50, y: 50 })
                          }}
                        >
                          <RefreshCcw className="h-3 w-3 mr-1" /> Restablecer
                        </Button>
                      </div>
                    </div>

                    <div className="mt-4 flex justify-center">
                      <div className="h-12 w-12 rounded-full overflow-hidden border-2 border-orange-300">
                        <div
                          className="h-full w-full"
                          style={{
                            backgroundImage: `url(${newLogoUrl})`,
                            backgroundSize: `${logoZoom}%`,
                            backgroundPosition: `${logoPosition.x}% ${logoPosition.y}%`,
                            backgroundRepeat: "no-repeat",
                          }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          <DialogFooter>
            {businessConfig.isConfigured ? (
              <>
                <Button
                  variant="outline"
                  onClick={() => {
                    if (businessConfig.isConfigured) {
                      setIsBusinessConfigDialogOpen(false)
                    }
                  }}
                >
                  Cancelar
                </Button>
                <Button onClick={saveBusinessConfig}>Guardar</Button>
              </>
            ) : (
              <>
                {setupStep > 1 && (
                  <Button variant="outline" onClick={() => setSetupStep(setupStep - 1)}>
                    Anterior
                  </Button>
                )}
                <Button onClick={continueSetup}>{setupStep < 2 ? "Siguiente" : "Finalizar"}</Button>
              </>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Logo Dialog */}
      <Dialog open={isLogoDialogOpen} onOpenChange={setIsLogoDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Cambiar Logo</DialogTitle>
            <DialogDescription>Personalice el logo de su negocio.</DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <LogoTabs value={logoTab} onValueChange={setLogoTab} className="w-full">
              <LogoTabsList className="grid w-full grid-cols-2">
                <LogoTabsTrigger value="url">URL</LogoTabsTrigger>
                <LogoTabsTrigger value="upload">Subir</LogoTabsTrigger>
              </LogoTabsList>

              <LogoTabsContent value="url" className="pt-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="logo-url" className="text-right">
                    URL
                  </Label>
                  <Input
                    id="logo-url"
                    value={newLogoUrl}
                    onChange={(e) => setNewLogoUrl(e.target.value)}
                    placeholder="https://ejemplo.com/mi-logo.png"
                    className="col-span-3"
                  />
                </div>
              </LogoTabsContent>

              <LogoTabsContent value="upload" className="pt-4">
                <div className="flex flex-col items-center gap-4">
                  <div
                    className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center cursor-pointer hover:bg-gray-50 dark:hover:bg-stone-800"
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <Upload className="h-8 w-8 mx-auto mb-2 text-gray-400" />
                    <p className="text-sm text-muted-foreground">Haga clic para seleccionar una imagen</p>
                    <input
                      type="file"
                      ref={fileInputRef}
                      className="hidden"
                      accept="image/*"
                      onChange={handleFileUpload}
                    />
                  </div>
                </div>
              </LogoTabsContent>
            </LogoTabs>

            <div className="flex justify-center mt-4">
              <Button
                variant="outline"
                onClick={() => {
                  setNewLogoUrl("default")
                  toast({
                    title: "Logo predeterminado seleccionado",
                    description: "Se usará el logo predeterminado",
                  })
                }}
                className="flex items-center gap-2"
              >
                <Store className="h-4 w-4" />
                <span>Usar Logo Predeterminado</span>
              </Button>
            </div>

            {newLogoUrl && newLogoUrl !== "default" && (
              <div className="space-y-4 pt-4">
                <div className="border-t pt-4 dark:border-stone-700">
                  <h3 className="text-sm font-medium mb-2">Ajustar Logo</h3>

                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="logo-zoom">Zoom</Label>
                      <Slider
                        id="logo-zoom"
                        min={50}
                        max={200}
                        step={5}
                        value={[logoZoom]}
                        onValueChange={(value) => setLogoZoom(value[0])}
                      />
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>50%</span>
                        <span>100%</span>
                        <span>200%</span>
                      </div>
                    </div>

                    <div className="mt-4">
                      <Label className="mb-2 block">Posición (Arrastre la imagen para ajustar)</Label>
                      <div
                        ref={logoContainerRef}
                        className="h-40 w-40 mx-auto border-2 border-orange-300 rounded-lg overflow-hidden relative"
                        onMouseMove={handleLogoMouseMove}
                        onMouseUp={handleLogoMouseUp}
                        onMouseLeave={handleLogoMouseUp}
                      >
                        <div
                          className="absolute inset-0 cursor-move"
                          style={{
                            backgroundImage: `url(${newLogoUrl})`,
                            backgroundSize: `${logoZoom}%`,
                            backgroundPosition: `${logoPosition.x}% ${logoPosition.y}%`,
                            backgroundRepeat: "no-repeat",
                          }}
                          onMouseDown={handleLogoMouseDown}
                        />
                      </div>
                    </div>

                    <div className="flex justify-center mt-4">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setLogoZoom(100)
                          setLogoPosition({ x: 50, y: 50 })
                        }}
                      >
                        <RefreshCcw className="h-3 w-3 mr-1" /> Restablecer
                      </Button>
                    </div>
                  </div>

                  <div className="mt-4 flex justify-center">
                    <div className="h-12 w-12 rounded-full overflow-hidden border-2 border-orange-300">
                      <div
                        className="h-full w-full"
                        style={{
                          backgroundImage: `url(${newLogoUrl})`,
                          backgroundSize: `${logoZoom}%`,
                          backgroundPosition: `${logoPosition.x}% ${logoPosition.y}%`,
                          backgroundRepeat: "no-repeat",
                        }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsLogoDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={saveLogo}>Guardar Logo</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Tutorial Dialog - Versión personalizada */}
      {isTutorialOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="relative w-full max-w-md bg-white rounded-lg shadow-lg dark:bg-stone-800">
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-semibold">
                  Tutorial - Paso {tutorialStep} de {totalTutorialSteps}
                </h2>
                <Button variant="ghost" size="icon" onClick={closeTutorial} className="h-8 w-8">
                  <X className="h-4 w-4" />
                </Button>
              </div>

              <div className="py-4">{renderTutorialContent()}</div>

              <div className="flex justify-between mt-6">
                <div>
                  {tutorialStep > 1 && (
                    <Button variant="outline" onClick={prevTutorialStep}>
                      Anterior
                    </Button>
                  )}
                </div>
                <div>
                  {tutorialStep < totalTutorialSteps ? (
                    <Button onClick={nextTutorialStep}>Siguiente</Button>
                  ) : (
                    <Button onClick={closeTutorial}>Finalizar</Button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      <Toaster />
    </div>
  )
}

